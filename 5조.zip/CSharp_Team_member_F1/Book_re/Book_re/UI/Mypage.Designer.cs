﻿
namespace Book_re
{
    partial class Mypage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mypage));
            this.bt_update_check = new Sunny.UI.UIButton();
            this.label_name = new System.Windows.Forms.Label();
            this.txt_phone = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.BS_bt_chart = new Sunny.UI.UIImageButton();
            this.BS_bt_recommend = new Sunny.UI.UIImageButton();
            this.BS_pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label_id = new System.Windows.Forms.Label();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ex_button = new Sunny.UI.UIButton();
            this.lb_borrowDate = new System.Windows.Forms.Label();
            this.lb_returnDate = new System.Windows.Forms.Label();
            this.bt_exit = new Sunny.UI.UIImageButton();
            this.bt_borrow = new Sunny.UI.UIButton();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.rentalListBindingSource6 = new System.Windows.Forms.BindingSource(this.components);
            this.gr_bookDeatail = new System.Windows.Forms.GroupBox();
            this.label_pw_check = new System.Windows.Forms.Label();
            this.txt_pwdck = new System.Windows.Forms.TextBox();
            this.txt_pwd = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rentalListBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.rentalListBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.rentalListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rentalListBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.rentalListBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.searchBookBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rentalListBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.bNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isbnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rentDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.returnDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BS_bt_chart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BS_bt_recommend)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BS_pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bt_exit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalListBindingSource6)).BeginInit();
            this.gr_bookDeatail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rentalListBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalListBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalListBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalListBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalListBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchBookBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalListBindingSource3)).BeginInit();
            this.SuspendLayout();
            // 
            // bt_update_check
            // 
            this.bt_update_check.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_update_check.FillColor = System.Drawing.Color.Maroon;
            this.bt_update_check.FillDisableColor = System.Drawing.Color.Maroon;
            this.bt_update_check.FillHoverColor = System.Drawing.Color.Maroon;
            this.bt_update_check.FillPressColor = System.Drawing.Color.Maroon;
            this.bt_update_check.FillSelectedColor = System.Drawing.Color.Maroon;
            this.bt_update_check.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.bt_update_check.Location = new System.Drawing.Point(109, 528);
            this.bt_update_check.MinimumSize = new System.Drawing.Size(1, 1);
            this.bt_update_check.Name = "bt_update_check";
            this.bt_update_check.Radius = 15;
            this.bt_update_check.RectColor = System.Drawing.Color.Maroon;
            this.bt_update_check.Size = new System.Drawing.Size(119, 43);
            this.bt_update_check.Style = Sunny.UI.UIStyle.Custom;
            this.bt_update_check.TabIndex = 69;
            this.bt_update_check.Text = "수정 확인";
            this.bt_update_check.Click += new System.EventHandler(this.bt_update_check_Click);
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_name.Location = new System.Drawing.Point(78, 73);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(53, 15);
            this.label_name.TabIndex = 56;
            this.label_name.Text = "label10";
            // 
            // txt_phone
            // 
            this.txt_phone.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_phone.Location = new System.Drawing.Point(94, 386);
            this.txt_phone.Name = "txt_phone";
            this.txt_phone.Size = new System.Drawing.Size(171, 25);
            this.txt_phone.TabIndex = 55;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(5);
            this.panel2.Size = new System.Drawing.Size(121, 680);
            this.panel2.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Maroon;
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.BS_bt_chart);
            this.panel3.Controls.Add(this.BS_bt_recommend);
            this.panel3.Controls.Add(this.BS_pictureBox1);
            this.panel3.Location = new System.Drawing.Point(10, 8);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(100, 672);
            this.panel3.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Aladin", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 369);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 38);
            this.label2.TabIndex = 4;
            this.label2.Text = "       장르별 \r\n 보유 책 현황";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Aladin", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(19, 212);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 38);
            this.label1.TabIndex = 3;
            this.label1.Text = " 도서관 \r\n   추천";
            // 
            // BS_bt_chart
            // 
            this.BS_bt_chart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BS_bt_chart.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.BS_bt_chart.Image = ((System.Drawing.Image)(resources.GetObject("BS_bt_chart.Image")));
            this.BS_bt_chart.Location = new System.Drawing.Point(20, 306);
            this.BS_bt_chart.Name = "BS_bt_chart";
            this.BS_bt_chart.Size = new System.Drawing.Size(60, 60);
            this.BS_bt_chart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BS_bt_chart.TabIndex = 2;
            this.BS_bt_chart.TabStop = false;
            this.BS_bt_chart.Text = null;
            // 
            // BS_bt_recommend
            // 
            this.BS_bt_recommend.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BS_bt_recommend.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.BS_bt_recommend.Image = ((System.Drawing.Image)(resources.GetObject("BS_bt_recommend.Image")));
            this.BS_bt_recommend.Location = new System.Drawing.Point(19, 149);
            this.BS_bt_recommend.Name = "BS_bt_recommend";
            this.BS_bt_recommend.Size = new System.Drawing.Size(60, 60);
            this.BS_bt_recommend.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BS_bt_recommend.TabIndex = 1;
            this.BS_bt_recommend.TabStop = false;
            this.BS_bt_recommend.Text = null;
            // 
            // BS_pictureBox1
            // 
            this.BS_pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("BS_pictureBox1.Image")));
            this.BS_pictureBox1.Location = new System.Drawing.Point(5, 3);
            this.BS_pictureBox1.Name = "BS_pictureBox1";
            this.BS_pictureBox1.Size = new System.Drawing.Size(90, 90);
            this.BS_pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BS_pictureBox1.TabIndex = 0;
            this.BS_pictureBox1.TabStop = false;
            // 
            // label_id
            // 
            this.label_id.AutoSize = true;
            this.label_id.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_id.Location = new System.Drawing.Point(94, 131);
            this.label_id.Name = "label_id";
            this.label_id.Size = new System.Drawing.Size(53, 15);
            this.label_id.TabIndex = 57;
            this.label_id.Text = "label11";
            // 
            // txt_email
            // 
            this.txt_email.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_email.Location = new System.Drawing.Point(94, 316);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(171, 25);
            this.txt_email.TabIndex = 54;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.ex_button);
            this.panel1.Controls.Add(this.lb_borrowDate);
            this.panel1.Controls.Add(this.lb_returnDate);
            this.panel1.Controls.Add(this.bt_exit);
            this.panel1.Controls.Add(this.bt_borrow);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.gr_bookDeatail);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1210, 680);
            this.panel1.TabIndex = 1;
            // 
            // ex_button
            // 
            this.ex_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ex_button.FillColor = System.Drawing.Color.Maroon;
            this.ex_button.FillDisableColor = System.Drawing.Color.Maroon;
            this.ex_button.FillHoverColor = System.Drawing.Color.Maroon;
            this.ex_button.FillPressColor = System.Drawing.Color.Maroon;
            this.ex_button.FillSelectedColor = System.Drawing.Color.Maroon;
            this.ex_button.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.ex_button.Location = new System.Drawing.Point(1017, 218);
            this.ex_button.MinimumSize = new System.Drawing.Size(1, 1);
            this.ex_button.Name = "ex_button";
            this.ex_button.Radius = 15;
            this.ex_button.RectColor = System.Drawing.Color.Maroon;
            this.ex_button.Size = new System.Drawing.Size(119, 40);
            this.ex_button.Style = Sunny.UI.UIStyle.Custom;
            this.ex_button.TabIndex = 71;
            this.ex_button.Text = "연장";
            this.ex_button.Click += new System.EventHandler(this.ex_button_Click);
            // 
            // lb_borrowDate
            // 
            this.lb_borrowDate.AutoSize = true;
            this.lb_borrowDate.Location = new System.Drawing.Point(672, 64);
            this.lb_borrowDate.Name = "lb_borrowDate";
            this.lb_borrowDate.Size = new System.Drawing.Size(11, 12);
            this.lb_borrowDate.TabIndex = 70;
            this.lb_borrowDate.Text = "-";
            // 
            // lb_returnDate
            // 
            this.lb_returnDate.AutoSize = true;
            this.lb_returnDate.Location = new System.Drawing.Point(672, 140);
            this.lb_returnDate.Name = "lb_returnDate";
            this.lb_returnDate.Size = new System.Drawing.Size(11, 12);
            this.lb_returnDate.TabIndex = 69;
            this.lb_returnDate.Text = "-";
            // 
            // bt_exit
            // 
            this.bt_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_exit.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.bt_exit.Image = ((System.Drawing.Image)(resources.GetObject("bt_exit.Image")));
            this.bt_exit.Location = new System.Drawing.Point(1132, 11);
            this.bt_exit.Name = "bt_exit";
            this.bt_exit.Size = new System.Drawing.Size(60, 60);
            this.bt_exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bt_exit.TabIndex = 68;
            this.bt_exit.TabStop = false;
            this.bt_exit.Text = null;
            this.bt_exit.Click += new System.EventHandler(this.bt_exit_Click);
            // 
            // bt_borrow
            // 
            this.bt_borrow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_borrow.FillColor = System.Drawing.Color.Maroon;
            this.bt_borrow.FillDisableColor = System.Drawing.Color.Maroon;
            this.bt_borrow.FillHoverColor = System.Drawing.Color.Maroon;
            this.bt_borrow.FillPressColor = System.Drawing.Color.Maroon;
            this.bt_borrow.FillSelectedColor = System.Drawing.Color.Maroon;
            this.bt_borrow.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.bt_borrow.Location = new System.Drawing.Point(875, 218);
            this.bt_borrow.MinimumSize = new System.Drawing.Size(1, 1);
            this.bt_borrow.Name = "bt_borrow";
            this.bt_borrow.Radius = 15;
            this.bt_borrow.RectColor = System.Drawing.Color.Maroon;
            this.bt_borrow.Size = new System.Drawing.Size(119, 40);
            this.bt_borrow.Style = Sunny.UI.UIStyle.Custom;
            this.bt_borrow.TabIndex = 67;
            this.bt_borrow.Text = "반납";
            this.bt_borrow.Click += new System.EventHandler(this.bt_borrow_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.dateTimePicker1.Location = new System.Drawing.Point(659, 220);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(188, 25);
            this.dateTimePicker1.TabIndex = 66;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Maroon;
            this.label5.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.ForeColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(560, 220);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 25);
            this.label5.TabIndex = 65;
            this.label5.Text = "반납일";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Maroon;
            this.label12.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.ForeColor = System.Drawing.Color.Transparent;
            this.label12.Location = new System.Drawing.Point(560, 132);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(93, 25);
            this.label12.TabIndex = 63;
            this.label12.Text = "반납예정일";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Maroon;
            this.label13.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.ForeColor = System.Drawing.Color.Transparent;
            this.label13.Location = new System.Drawing.Point(560, 56);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(93, 25);
            this.label13.TabIndex = 61;
            this.label13.Text = "대여일";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bNameDataGridViewTextBoxColumn,
            this.isbnDataGridViewTextBoxColumn,
            this.rentDateDataGridViewTextBoxColumn,
            this.returnDateDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.rentalListBindingSource6;
            this.dataGridView1.Location = new System.Drawing.Point(563, 295);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(608, 340);
            this.dataGridView1.TabIndex = 58;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // rentalListBindingSource6
            // 
            this.rentalListBindingSource6.DataSource = typeof(Book_re.RentalList);
            // 
            // gr_bookDeatail
            // 
            this.gr_bookDeatail.Controls.Add(this.label_pw_check);
            this.gr_bookDeatail.Controls.Add(this.bt_update_check);
            this.gr_bookDeatail.Controls.Add(this.label_id);
            this.gr_bookDeatail.Controls.Add(this.label_name);
            this.gr_bookDeatail.Controls.Add(this.txt_phone);
            this.gr_bookDeatail.Controls.Add(this.txt_email);
            this.gr_bookDeatail.Controls.Add(this.txt_pwdck);
            this.gr_bookDeatail.Controls.Add(this.txt_pwd);
            this.gr_bookDeatail.Controls.Add(this.label9);
            this.gr_bookDeatail.Controls.Add(this.label7);
            this.gr_bookDeatail.Controls.Add(this.label8);
            this.gr_bookDeatail.Controls.Add(this.label3);
            this.gr_bookDeatail.Controls.Add(this.label4);
            this.gr_bookDeatail.Controls.Add(this.label6);
            this.gr_bookDeatail.Location = new System.Drawing.Point(155, 22);
            this.gr_bookDeatail.Name = "gr_bookDeatail";
            this.gr_bookDeatail.Size = new System.Drawing.Size(363, 613);
            this.gr_bookDeatail.TabIndex = 60;
            this.gr_bookDeatail.TabStop = false;
            this.gr_bookDeatail.Text = "상세정보";
            // 
            // label_pw_check
            // 
            this.label_pw_check.AutoSize = true;
            this.label_pw_check.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_pw_check.Location = new System.Drawing.Point(35, 273);
            this.label_pw_check.Name = "label_pw_check";
            this.label_pw_check.Size = new System.Drawing.Size(53, 15);
            this.label_pw_check.TabIndex = 70;
            this.label_pw_check.Text = "label12";
            // 
            // txt_pwdck
            // 
            this.txt_pwdck.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_pwdck.Location = new System.Drawing.Point(144, 235);
            this.txt_pwdck.Name = "txt_pwdck";
            this.txt_pwdck.PasswordChar = '*';
            this.txt_pwdck.Size = new System.Drawing.Size(171, 25);
            this.txt_pwdck.TabIndex = 53;
            this.txt_pwdck.TextChanged += new System.EventHandler(this.txt_pwdck_TextChanged);
            // 
            // txt_pwd
            // 
            this.txt_pwd.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_pwd.Location = new System.Drawing.Point(109, 184);
            this.txt_pwd.Name = "txt_pwd";
            this.txt_pwd.PasswordChar = '*';
            this.txt_pwd.Size = new System.Drawing.Size(171, 25);
            this.txt_pwd.TabIndex = 52;
            this.txt_pwd.TextChanged += new System.EventHandler(this.txt_pwd_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.Location = new System.Drawing.Point(26, 389);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 15);
            this.label9.TabIndex = 15;
            this.label9.Text = "연락처 :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(26, 319);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 15);
            this.label7.TabIndex = 14;
            this.label7.Text = "이메일 :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(26, 238);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 15);
            this.label8.TabIndex = 13;
            this.label8.Text = "비밀번호 확인 :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(26, 187);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 15);
            this.label3.TabIndex = 9;
            this.label3.Text = "비밀번호 :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(26, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "아이디 :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(26, 73);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 15);
            this.label6.TabIndex = 7;
            this.label6.Text = "이름 :";
            // 
            // bNameDataGridViewTextBoxColumn
            // 
            this.bNameDataGridViewTextBoxColumn.DataPropertyName = "bName";
            this.bNameDataGridViewTextBoxColumn.HeaderText = "제목";
            this.bNameDataGridViewTextBoxColumn.Name = "bNameDataGridViewTextBoxColumn";
            // 
            // isbnDataGridViewTextBoxColumn
            // 
            this.isbnDataGridViewTextBoxColumn.DataPropertyName = "isbn";
            this.isbnDataGridViewTextBoxColumn.HeaderText = "isbn";
            this.isbnDataGridViewTextBoxColumn.Name = "isbnDataGridViewTextBoxColumn";
            // 
            // rentDateDataGridViewTextBoxColumn
            // 
            this.rentDateDataGridViewTextBoxColumn.DataPropertyName = "rentDate";
            this.rentDateDataGridViewTextBoxColumn.HeaderText = "대여날짜";
            this.rentDateDataGridViewTextBoxColumn.Name = "rentDateDataGridViewTextBoxColumn";
            // 
            // returnDateDataGridViewTextBoxColumn
            // 
            this.returnDateDataGridViewTextBoxColumn.DataPropertyName = "returnDate";
            this.returnDateDataGridViewTextBoxColumn.HeaderText = "반납예정일";
            this.returnDateDataGridViewTextBoxColumn.Name = "returnDateDataGridViewTextBoxColumn";
            // 
            // Mypage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1220, 690);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Mypage";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.Text = "Mypage";
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BS_bt_chart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BS_bt_recommend)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BS_pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bt_exit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalListBindingSource6)).EndInit();
            this.gr_bookDeatail.ResumeLayout(false);
            this.gr_bookDeatail.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rentalListBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalListBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalListBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalListBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalListBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchBookBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalListBindingSource3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UIButton bt_update_check;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.TextBox txt_phone;
        private System.Windows.Forms.BindingSource rentalListBindingSource2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Sunny.UI.UIImageButton BS_bt_chart;
        private Sunny.UI.UIImageButton BS_bt_recommend;
        private System.Windows.Forms.PictureBox BS_pictureBox1;
        private System.Windows.Forms.Label label_id;
        private System.Windows.Forms.BindingSource rentalListBindingSource;
        private System.Windows.Forms.BindingSource rentalListBindingSource4;
        private System.Windows.Forms.BindingSource rentalListBindingSource1;
        private System.Windows.Forms.BindingSource searchBookBindingSource;
        private System.Windows.Forms.BindingSource rentalListBindingSource3;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.Panel panel1;
        private Sunny.UI.UIButton ex_button;
        private System.Windows.Forms.Label lb_borrowDate;
        private System.Windows.Forms.Label lb_returnDate;
        private Sunny.UI.UIImageButton bt_exit;
        private Sunny.UI.UIButton bt_borrow;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource rentalListBindingSource5;
        private System.Windows.Forms.GroupBox gr_bookDeatail;
        private System.Windows.Forms.TextBox txt_pwdck;
        private System.Windows.Forms.TextBox txt_pwd;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label_pw_check;
        private System.Windows.Forms.BindingSource rentalListBindingSource6;
        private System.Windows.Forms.DataGridViewTextBoxColumn bNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn isbnDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rentDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn returnDateDataGridViewTextBoxColumn;
    }
}