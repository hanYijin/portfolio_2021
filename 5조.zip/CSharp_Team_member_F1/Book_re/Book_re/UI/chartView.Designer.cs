﻿
namespace Book_re
{
    partial class chartView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea34 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend34 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series34 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea35 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend35 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series35 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea36 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend36 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series36 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea37 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend37 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series37 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea38 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend38 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series38 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea39 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend39 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series39 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea40 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend40 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series40 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea41 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend41 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series41 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea42 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend42 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series42 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea43 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend43 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series43 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea44 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend44 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series44 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(chartView));
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart4 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart5 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart6 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart7 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart8 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart9 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart10 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart11 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_exit = new Sunny.UI.UIImageButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bt_exit)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // chart1
            // 
            chartArea34.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea34);
            legend34.Name = "Legend1";
            this.chart1.Legends.Add(legend34);
            this.chart1.Location = new System.Drawing.Point(12, 12);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series34.ChartArea = "ChartArea1";
            series34.Legend = "Legend1";
            series34.Name = "Series1";
            this.chart1.Series.Add(series34);
            this.chart1.Size = new System.Drawing.Size(357, 381);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            // 
            // chart2
            // 
            chartArea35.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea35);
            legend35.Name = "Legend1";
            this.chart2.Legends.Add(legend35);
            this.chart2.Location = new System.Drawing.Point(366, 141);
            this.chart2.Name = "chart2";
            this.chart2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright;
            series35.ChartArea = "ChartArea1";
            series35.Legend = "Legend1";
            series35.Name = "Series1";
            this.chart2.Series.Add(series35);
            this.chart2.Size = new System.Drawing.Size(239, 252);
            this.chart2.TabIndex = 1;
            this.chart2.Text = "chart2";
            // 
            // chart3
            // 
            chartArea36.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea36);
            legend36.Name = "Legend1";
            this.chart3.Legends.Add(legend36);
            this.chart3.Location = new System.Drawing.Point(598, 141);
            this.chart3.Name = "chart3";
            this.chart3.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Light;
            series36.ChartArea = "ChartArea1";
            series36.Legend = "Legend1";
            series36.Name = "Series1";
            this.chart3.Series.Add(series36);
            this.chart3.Size = new System.Drawing.Size(239, 252);
            this.chart3.TabIndex = 2;
            this.chart3.Text = "chart3";
            // 
            // chart4
            // 
            chartArea37.Name = "ChartArea1";
            this.chart4.ChartAreas.Add(chartArea37);
            legend37.Name = "Legend1";
            this.chart4.Legends.Add(legend37);
            this.chart4.Location = new System.Drawing.Point(830, 141);
            this.chart4.Name = "chart4";
            this.chart4.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series37.ChartArea = "ChartArea1";
            series37.Legend = "Legend1";
            series37.Name = "Series1";
            this.chart4.Series.Add(series37);
            this.chart4.Size = new System.Drawing.Size(239, 252);
            this.chart4.TabIndex = 3;
            this.chart4.Text = "chart4";
            // 
            // chart5
            // 
            chartArea38.Name = "ChartArea1";
            this.chart5.ChartAreas.Add(chartArea38);
            legend38.Name = "Legend1";
            this.chart5.Legends.Add(legend38);
            this.chart5.Location = new System.Drawing.Point(1057, 141);
            this.chart5.Name = "chart5";
            this.chart5.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series38.ChartArea = "ChartArea1";
            series38.Legend = "Legend1";
            series38.Name = "Series1";
            this.chart5.Series.Add(series38);
            this.chart5.Size = new System.Drawing.Size(239, 252);
            this.chart5.TabIndex = 4;
            this.chart5.Text = "chart5";
            // 
            // chart6
            // 
            chartArea39.Name = "ChartArea1";
            this.chart6.ChartAreas.Add(chartArea39);
            legend39.Name = "Legend1";
            this.chart6.Legends.Add(legend39);
            this.chart6.Location = new System.Drawing.Point(12, 399);
            this.chart6.Name = "chart6";
            this.chart6.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.EarthTones;
            series39.ChartArea = "ChartArea1";
            series39.Legend = "Legend1";
            series39.Name = "Series1";
            this.chart6.Series.Add(series39);
            this.chart6.Size = new System.Drawing.Size(217, 252);
            this.chart6.TabIndex = 5;
            this.chart6.Text = "chart6";
            // 
            // chart7
            // 
            chartArea40.Name = "ChartArea1";
            this.chart7.ChartAreas.Add(chartArea40);
            legend40.Name = "Legend1";
            this.chart7.Legends.Add(legend40);
            this.chart7.Location = new System.Drawing.Point(225, 399);
            this.chart7.Name = "chart7";
            series40.ChartArea = "ChartArea1";
            series40.Legend = "Legend1";
            series40.Name = "Series1";
            this.chart7.Series.Add(series40);
            this.chart7.Size = new System.Drawing.Size(217, 252);
            this.chart7.TabIndex = 6;
            this.chart7.Text = "chart7";
            // 
            // chart8
            // 
            chartArea41.Name = "ChartArea1";
            this.chart8.ChartAreas.Add(chartArea41);
            legend41.Name = "Legend1";
            this.chart8.Legends.Add(legend41);
            this.chart8.Location = new System.Drawing.Point(439, 399);
            this.chart8.Name = "chart8";
            this.chart8.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Berry;
            series41.ChartArea = "ChartArea1";
            series41.Legend = "Legend1";
            series41.Name = "Series1";
            this.chart8.Series.Add(series41);
            this.chart8.Size = new System.Drawing.Size(217, 252);
            this.chart8.TabIndex = 7;
            this.chart8.Text = "chart8";
            // 
            // chart9
            // 
            chartArea42.Name = "ChartArea1";
            this.chart9.ChartAreas.Add(chartArea42);
            legend42.Name = "Legend1";
            this.chart9.Legends.Add(legend42);
            this.chart9.Location = new System.Drawing.Point(653, 399);
            this.chart9.Name = "chart9";
            this.chart9.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Chocolate;
            series42.ChartArea = "ChartArea1";
            series42.Legend = "Legend1";
            series42.Name = "Series1";
            this.chart9.Series.Add(series42);
            this.chart9.Size = new System.Drawing.Size(217, 252);
            this.chart9.TabIndex = 8;
            this.chart9.Text = "chart9";
            // 
            // chart10
            // 
            chartArea43.Name = "ChartArea1";
            this.chart10.ChartAreas.Add(chartArea43);
            legend43.Name = "Legend1";
            this.chart10.Legends.Add(legend43);
            this.chart10.Location = new System.Drawing.Point(866, 399);
            this.chart10.Name = "chart10";
            this.chart10.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Fire;
            series43.ChartArea = "ChartArea1";
            series43.Legend = "Legend1";
            series43.Name = "Series1";
            this.chart10.Series.Add(series43);
            this.chart10.Size = new System.Drawing.Size(217, 252);
            this.chart10.TabIndex = 9;
            this.chart10.Text = "chart10";
            // 
            // chart11
            // 
            chartArea44.Name = "ChartArea1";
            this.chart11.ChartAreas.Add(chartArea44);
            legend44.Name = "Legend1";
            this.chart11.Legends.Add(legend44);
            this.chart11.Location = new System.Drawing.Point(1079, 399);
            this.chart11.Name = "chart11";
            this.chart11.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SeaGreen;
            series44.ChartArea = "ChartArea1";
            series44.Legend = "Legend1";
            series44.Name = "Series1";
            this.chart11.Series.Add(series44);
            this.chart11.Size = new System.Drawing.Size(217, 252);
            this.chart11.TabIndex = 10;
            this.chart11.Text = "chart11";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("굴림", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(448, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(708, 48);
            this.label1.TabIndex = 11;
            this.label1.Text = "장르별 책보유 현황 및 대출건수";
            // 
            // bt_exit
            // 
            this.bt_exit.BackColor = System.Drawing.Color.White;
            this.bt_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_exit.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.bt_exit.Image = ((System.Drawing.Image)(resources.GetObject("bt_exit.Image")));
            this.bt_exit.Location = new System.Drawing.Point(1194, 36);
            this.bt_exit.Name = "bt_exit";
            this.bt_exit.Size = new System.Drawing.Size(60, 60);
            this.bt_exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bt_exit.TabIndex = 12;
            this.bt_exit.TabStop = false;
            this.bt_exit.Text = null;
            this.bt_exit.Click += new System.EventHandler(this.bt_exit_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Maroon;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(5);
            this.panel1.Size = new System.Drawing.Size(1309, 684);
            this.panel1.TabIndex = 13;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(6, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1298, 676);
            this.panel2.TabIndex = 0;
            // 
            // chartView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1309, 684);
            this.Controls.Add(this.bt_exit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chart11);
            this.Controls.Add(this.chart10);
            this.Controls.Add(this.chart9);
            this.Controls.Add(this.chart8);
            this.Controls.Add(this.chart7);
            this.Controls.Add(this.chart6);
            this.Controls.Add(this.chart5);
            this.Controls.Add(this.chart4);
            this.Controls.Add(this.chart3);
            this.Controls.Add(this.chart2);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "chartView";
            this.Text = "장르별 책 보유 현황";
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bt_exit)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart4;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart5;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart6;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart7;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart8;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart9;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart10;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart11;
        private System.Windows.Forms.Label label1;
        private Sunny.UI.UIImageButton bt_exit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}