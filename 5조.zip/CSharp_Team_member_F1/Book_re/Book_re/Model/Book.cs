﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Book_re
{
    class Book
    {
        public string bookrank { get; set; }
        public string bid { get; set; }
        public string title { get; set; }
        public string writer { get; set; }
        public string publisher { get; set; }
        public string pyear { get; set; }
        public string category { get; set; }
    }
}
